﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FolandMusic
{
    public partial class ChangePassword : Form
    {
        public ChangePassword()
        {
            InitializeComponent();
        }
        public static MsUser user = new MsUser();

        private void button1_Click(object sender, EventArgs e)
        { 

            using (Entities3 db = new Entities3())
            {
                if (old.Text == "")
                {
                    MessageBox.Show("Old password can’t be empty!");
                }
                else if (old.Text != user.UserPassword)
                {
                    MessageBox.Show("Incorrect old password!");
                }
                else if (newpass.Text == "")
                {
                    MessageBox.Show("New password can’t be empty!");
                }
                else if (newpass.Text == user.UserPassword)
                {
                    MessageBox.Show("New password can’t be the same as old password!");
                }
                else if (newpass.Text.Length < 6 && newpass.Text.Length > 15)
                {
                    MessageBox.Show("Password must be between 6 and 15 characters!");
                }
                else if (confirm.Text != newpass.Text)
                {
                    MessageBox.Show("Confirm password doesn’t match!");
                }
                else
                {
                    string id = Login.user.UserID;
                    user = db.MsUsers.Where(y => y.UserID == id).FirstOrDefault();
                    user.UserPassword = newpass.Text;
                    
                }
                db.Entry(user).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                MessageBox.Show("Change Password Success!");
                MessageBox.Show("Please re-login to update your password!");
                this.Close();
                Login login = new Login();
                login.Close();
                Main main = new Main();
                main.Show();
           
            }

        }

        private void ChangePassword_Load(object sender, EventArgs e)
        {

        }
    }
}
