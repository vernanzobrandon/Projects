﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FolandMusic
{
    public partial class MasterUserForm : Form
    {
        MsUser user = new MsUser();
        string Gender;
        int indexx = 1;
        public MasterUserForm()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            Gender = "Male";
        }

        private void MasterUserForm_Load(object sender, EventArgs e)
        {
            using (Entities3 db = new Entities3())
            {
                var query = from x in db.MsUsers
                            select new
                            {
                                UserID = x.UserID,
                                Role = x.UserRole,
                                Name = x.UserName,
                                Email = x.UserEmail,
                                Gender = x.UserGender,
                                DOB = x.UserDOB,
                                PhoneNumber = x.UserPhone,
                                Address = x.UserAddress
                            };
                dataGridView1.DataSource = query.ToList();

            }
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
            textBox5.Enabled = false;
            comboBox1.Enabled = false;
            radioButton1.Enabled = false;
            radioButton2.Enabled = false;
            dateTimePicker1.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            Gender = "Female";
        }

        private void flick()
        {
            using (Entities3 db = new Entities3())
            {
                var query = from x in db.MsUsers
                            select new
                            {
                                UserID = x.UserID,
                                Role = x.UserRole,
                                Name = x.UserName,
                                Email = x.UserEmail,
                                Gender = x.UserGender,
                                DOB = x.UserDOB,
                                PhoneNumber = x.UserPhone,
                                Address = x.UserAddress
                            };
                dataGridView1.DataSource = query.ToList();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentRow.Index != -1)
            {
                var IDBaru = Convert.ToString(dataGridView1.CurrentRow.Cells["UserID"].Value);
                using (Entities3 db = new Entities3())
                {
                    var abc = db.MsUsers.Where(indexx => indexx.UserID == IDBaru).FirstOrDefault();
                    textBox1.Text = dataGridView1.CurrentRow.Cells["UserID"].Value.ToString();
                    textBox2.Text = abc.UserName;
                    textBox3.Text = dataGridView1.CurrentRow.Cells["Email"].Value.ToString();
                    textBox4.Text = Convert.ToString(abc.UserPhone);
                    textBox5.Text = dataGridView1.CurrentRow.Cells["Address"].Value.ToString();

                    if (dataGridView1.CurrentRow.Cells["Gender"].Value.ToString() == "Male")
                    {
                        radioButton1.Select();
                    }
                    if (dataGridView1.CurrentRow.Cells["Gender"].Value.ToString() == "Female")
                    {
                        radioButton2.Select();
                    }
                    dateTimePicker1.Value = Convert.ToDateTime(dataGridView1.CurrentRow.Cells["DOB"].Value);

                    if (dataGridView1.CurrentRow.Cells["Role"].Value.ToString() == "Member")
                    {
                        comboBox1.Text = "Member";
                    }
                    if (dataGridView1.CurrentRow.Cells["Role"].Value.ToString() == "Admin")
                    {
                        comboBox1.Text = "Admin";
                    }
                }

            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string idx;
            Entities3 db = new Entities3();
            var display = db.MsUsers.OrderByDescending(A => A.UserID).FirstOrDefault();
            {
                if (display == null)
                {
                    idx = "US001";
                }
                else
                {
                    int id1 = (Convert.ToInt32(display.UserID.Substring(display.UserID.Length - 3)) + 1);
                    idx = "US" + id1.ToString().PadLeft(3, '0');
                }
                
                textBox1.Text = idx;
                textBox1.Enabled = false;
                textBox2.Enabled = true;
                textBox3.Enabled = true;
                textBox4.Enabled = true;
                textBox5.Enabled = true;
                comboBox1.Enabled = true;
                radioButton1.Enabled = true;
                radioButton2.Enabled = true;
                dateTimePicker1.Enabled = true;
                button4.Enabled = true;
                button5.Enabled = true;
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
            textBox2.Enabled = true;
            textBox3.Enabled = true;
            textBox4.Enabled = true;
            textBox5.Enabled = true;
            comboBox1.Enabled = true;
            radioButton1.Enabled = true;
            radioButton2.Enabled = true;
            dateTimePicker1.Enabled = true;
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            using (Entities3 db = new Entities3())
            {
                string id2 = textBox1.Text;
                user = db.MsUsers.Where(xx => xx.UserID == id2).FirstOrDefault();
                if (user == null)
                {
                    MessageBox.Show("Please Select An User!");
                }
                else
                {
                    db.MsUsers.Remove(user);
                    db.SaveChanges();
                }
                this.Hide();
                MasterUserForm MUF = new MasterUserForm();
                MUF.Show();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Entities3 db = new Entities3();
            var display1 = db.MsUsers.Where(xx => xx.UserID == textBox1.Text).FirstOrDefault();
            if (comboBox1.Text == "")
            {
                MessageBox.Show("Role must be selected!");
            }
            if (textBox2.Text == "")
            {
                MessageBox.Show("Name Can't Be Empty!");
            }
            else if (textBox2.Text.Length < 3 || textBox1.Text.Length > 15)
            {
                MessageBox.Show("Name Must Be Between 3 And 15 Characters!");
            }
            else if (!radioButton1.Checked && !radioButton2.Checked)
            {
                MessageBox.Show("Gender Must Be Selected!");
            }
            else if (textBox3.Text == "")
            {
                MessageBox.Show("Email Can't Be Empty");
            }
            else if (dateTimePicker1.Value.Year > 2009)
            {
                MessageBox.Show("You Must Be At Least 10 Years Old To Register!");
            }
            else if (textBox4.Text.Length < 9)
            {
                MessageBox.Show("Phone Number Must Be More Then 9 Characters!");
            }
            else if (textBox4.Text == "")
            {
                MessageBox.Show("Phone Number Can't Be Empty!");
            }
            else if (textBox5.Text == "")
            {
                MessageBox.Show("Address Can't Be Empty!");
            }
            else if (!(textBox5.Text.Substring(textBox5.Text.Length - 6) == "street"))
            {
                MessageBox.Show("Address Must Ends With ‘Street’!");
            }
            else if (display1 == null)
            {
                user.UserID = textBox1.Text;
                user.UserName = textBox2.Text;
                user.UserEmail = textBox3.Text;
                user.UserPassword = "default";
                user.UserRole = Convert.ToString(comboBox1.Text);
                user.UserDOB = dateTimePicker1.Value;
                user.UserPhone = textBox4.Text;
                user.UserGender = Gender;
                user.UserAddress = textBox5.Text;
                db.MsUsers.Add(user);
                db.SaveChanges();
                this.Hide();
                MasterUserForm MUF = new MasterUserForm();
                MUF.Show();
            }
            else
            {
                string IdBaru = textBox1.Text;
                user.UserName = textBox2.Text;
                user.UserEmail = textBox3.Text;
                user.UserRole = Convert.ToString(comboBox1.Text);
                user.UserDOB = dateTimePicker1.Value;
                user.UserPhone = textBox4.Text;
                user.UserGender = Gender;
                user.UserAddress = textBox5.Text;
                user = db.MsUsers.Where(X => X.UserID == IdBaru).FirstOrDefault();
                db.Entry(user).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                this.Hide();
                MasterUserForm MUF = new MasterUserForm();
                MUF.Show();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            MasterUserForm MUF = new MasterUserForm();
            MUF.Show();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {

            }
            else
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
                MessageBox.Show("Phone Number Must Be Numeric");
            }
        }
    }
}
