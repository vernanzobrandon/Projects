﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FolandMusic
{
    public partial class Staff : Form
    {
        public Staff()
        {
            InitializeComponent();
        }

        private void usersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MasterUserForm ahay = new MasterUserForm();
            ahay.Show();
        }

        private void typeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MasterProduct aye = new MasterProduct();
            aye.Show();
        }

        private void Staff_Load(object sender, EventArgs e)
        {

        }
    }
}
