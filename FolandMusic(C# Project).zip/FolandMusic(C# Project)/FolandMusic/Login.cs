﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FolandMusic
{
    public partial class Login : Form
    {
        public static MsUser user = new MsUser();
        //MsUser user = new MsUser();

        public Login()
        {
            InitializeComponent();
        }

        private void Loginbtn_Click(object sender, EventArgs e)
        {
            using (Entities3 db = new Entities3())
            {
                user = db.MsUsers.Where(A => A.UserEmail == email.Text && A.UserPassword == password.Text).FirstOrDefault();
                if (user == null) MessageBox.Show("Incorrect Email or Password!");
                else if (user.UserRole == "Member")
                {
                    MessageBox.Show("Login success!");
                    Member mem = new Member();
                    mem.Show();

                }
                else if (user.UserRole == "Staff")
                {
                    MessageBox.Show("Login success!");
                    Staff adm = new Staff();
                    adm.Show();

                }
                else if (user.UserPassword == "" && user.UserEmail=="")
                {
                    MessageBox.Show("Email or Password can’t be empty!");
                }
                this.Close();
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
