﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FolandMusic
{
    public partial class BuyInstrument : Form
    {
        MsProduct prod = new MsProduct();
        public static string ProductID1;
        public static string TypeID1;
        public static string Nama;
        public static string Type;
        public static int Price;
        public static int Stock;
        public static int Quantity;
        public static int TotalPrice;

        public BuyInstrument()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void BuyInstrument_Load(object sender, EventArgs e)
        {
            Entities3 db = new Entities3();
           

            var product = from p in db.MsProducts join t in db.MsTypes on p.TypeId equals t.TypeID select new {
                ProductID = p.ProductID,
                TypeName = t.TypeName,
                ProductName = p.ProductName,
                ProductPrice = p.ProductPrice,
                ProductStock = p.ProductStock
            };
            dataGridView1.DataSource = product.ToList();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
               DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
               textBox1.Text = row.Cells["TypeName"].Value.ToString();
               textBox2.Text = row.Cells["ProductName"].Value.ToString();
               textBox3.Text = row.Cells["ProductPrice"].Value.ToString();
               textBox4.Text = row.Cells["ProductStock"].Value.ToString();
                Price = Convert.ToInt32(textBox3.Text);
                Quantity = Convert.ToInt32(numericUpDown1.Value);
                TotalPrice = Price * Quantity;
                textBox5.Text = Convert.ToString(Convert.ToInt32(TotalPrice));

            }
           
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Nama = textBox1.Text;
            Type = textBox2.Text;
            Price = Convert.ToInt32(textBox3.Text);
            Stock = Convert.ToInt32(textBox4.Text);
            Quantity = Convert.ToInt32(numericUpDown1.Value);
            TotalPrice = Convert.ToInt32(textBox5.Text);
            if (prod==null)
            {
                MessageBox.Show("Empty!");
            }
            else
            {
                DialogResult dialog = MessageBox.Show("To Payment?","To Payment?",MessageBoxButtons.YesNo);
                if (dialog == DialogResult.Yes)
                {

                    this.Hide();
                    payment bayar = new payment();
                    bayar.Show();
                }
            }
            }
    }
}
