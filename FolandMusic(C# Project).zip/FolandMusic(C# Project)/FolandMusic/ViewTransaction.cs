﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FolandMusic
{
    public partial class ViewTransaction : Form
    {
        public ViewTransaction()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void ViewTransaction_Load(object sender, EventArgs e)
        {
            Entities3 db = new Entities3();
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
            textBox5.Enabled = false;
            textBox6.Enabled = false;
            textBox7.Enabled = false;
            textBox8.Enabled = false;
            textBox9.Enabled = false;
            textBox10.Enabled = false;
            dateTimePicker1.Enabled = false;
            var query = from top in db.HeaderTransactions
                        join bot in db.DetailTransactions on top.TransactionID equals bot.TransactionID
                        select new
                        {
                            TransactionID = top.TransactionID,
                            UserID = top.UserID,
                            TransactionDate = top.TransactionDate,
                            ProductID = bot.ProductID,
                            Quantity = bot.Quantity
                        };
            dataGridView1.DataSource = query.ToList();
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (dataGridView1.CurrentRow.Index != -1)
            {
                var display1 = Convert.ToString(dataGridView1.CurrentRow.Cells["TransactionID"].Value);
                var display2 = Convert.ToString(dataGridView1.CurrentRow.Cells["ProductID"].Value);
                var display3 = Convert.ToString(dataGridView1.CurrentRow.Cells["UserID"].Value);

                using (Entities3 db = new Entities3())
                {
                    var displayx1 = db.HeaderTransactions.Where(xx => xx.TransactionID == display1).FirstOrDefault();
                    var displayx2 = db.DetailTransactions.Where(xx => xx.TransactionID == display1).FirstOrDefault();
                    var displayx3 = db.MsUsers.Where(xx => xx.UserID == display3).FirstOrDefault();
                    var displayx4 = db.MsProducts.Where(xx => xx.ProductID == display2).FirstOrDefault();
                    var displayx5 = db.MsTypes.Where(xx => xx.TypeID == displayx4.TypeId).FirstOrDefault();
                    textBox1.Text = displayx1.TransactionID;
                    textBox2.Text = displayx2.ProductID;
                    textBox3.Text = displayx4.ProductName;
                    textBox4.Text = displayx5.TypeName;
                    textBox5.Text = Convert.ToString(displayx4.ProductPrice);
                    textBox6.Text = Convert.ToString(displayx2.Quantity);
                    textBox7.Text = displayx1.UserID;
                    textBox8.Text = displayx3.UserName;
                    textBox9.Text = displayx3.UserPhone;
                    textBox10.Text = displayx3.UserAddress;
                    dateTimePicker1.Value = displayx1.TransactionDate;
                }
            }
        }
    }
}
    
