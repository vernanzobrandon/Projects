﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FolandMusic
{
    public partial class MasterType : Form
    {
        MsType Ty = new MsType();
        public MasterType()
        {
            InitializeComponent();
        }

        private void MasterType_Load(object sender, EventArgs e)
        {
            using (Entities3 db = new Entities3())
            {
                var query1 = from x in db.MsTypes
                            select new
                            {
                            TypeID = x.TypeID,
                            TypeName = x.TypeName,
                            };
                dataGridView1.DataSource = query1.ToList();
            }
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            button5.Enabled = false;
            button4.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        { 
            string idx;
            Entities3 db = new Entities3();
            var model = db.MsTypes.OrderByDescending(u => u.TypeID).FirstOrDefault();
            if (model == null)
            {
                idx = "TP001";
            }
            else
            {
                int idangka = (Convert.ToInt32(model.TypeID.Substring(model.TypeID.Length - 3)) + 1);
                idx = "TP" + idangka.ToString().PadLeft(3, '0');
            }
            textBox1.Text = idx;
            textBox1.Enabled = false;
            textBox2.Enabled = true;
            button1.Enabled = false;
            button2.Enabled = true;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
            textBox2.Enabled = true;
            button1.Enabled = false;
            button2.Enabled = true;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            using (Entities3 db = new Entities3())
            {
                string idx = textBox1.Text;
                var display = db.MsTypes.Where(xx => xx.TypeID == idx).FirstOrDefault();
                if (display == null)
                {
                    MessageBox.Show("Please select an user!");
                }
                else
                {

                    DialogResult dialog = MessageBox.Show("Confirmation Message", "Are you sure?", MessageBoxButtons.YesNo);
                    if (dialog == DialogResult.Yes)
                    {
                        db.MsTypes.Remove(display);
                        db.SaveChanges();
                        this.Hide();
                        MasterType MST = new MasterType();
                        MST.Show();
                    }

                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Entities3 db = new Entities3();
            var display = db.MsTypes.Where(xx => xx.TypeID == textBox1.Text).FirstOrDefault();
            if (textBox2.Text == "")
            {
                MessageBox.Show("Type name can’t be empty!");
            }
            else if (textBox2.Text.Length < 5 && textBox2.Text.Length > 20)
            {
                MessageBox.Show("Type name must be between 5 and 20 characters!");
            }
            else if (display == null)
            {
                Ty.TypeID = textBox1.Text;
                Ty.TypeName = textBox2.Text;

                db.MsTypes.Add(Ty);
                db.SaveChanges();
                MessageBox.Show("Success!");
                this.Hide();
                MasterType MST = new MasterType();
                MST.Show();

            }
            else
            {
                var display1 = db.MsTypes.Where(xx => xx.TypeID == textBox1.Text).FirstOrDefault();
                display1.TypeName = textBox2.Text;

                db.Entry(display1).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                MessageBox.Show("Success!");
                this.Hide();
                MasterType MST = new MasterType();
                MST.Show();


            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            MasterType MST = new MasterType();
            MST.Show();
        }
    }
}
