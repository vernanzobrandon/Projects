﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FolandMusic
{
    
    public partial class payment : Form
    {
        public static payment bayar = new payment();
        public payment()
        {
            InitializeComponent();
        }

        private void payment_Load(object sender, EventArgs e)
        {
         
            Entities3 db = new Entities3();
            label5.Text = BuyInstrument.Type;
            label6.Text = BuyInstrument.Nama;
            label7.Text = Convert.ToString(BuyInstrument.Price);
            label8.Text = Convert.ToString(BuyInstrument.Quantity);
            label10.Text = Convert.ToString(BuyInstrument.TotalPrice);
            
               
                }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Payment can’t be empty!");
            }

            else if (Convert.ToInt32(textBox1.Text) < Convert.ToInt32(label10.Text))
            {
                MessageBox.Show("Payment can’t be less than total price!");
            }
            else
            {
                DialogResult dialog = MessageBox.Show("Confirmation Message", "Are you sure?", MessageBoxButtons.YesNo);
                if (dialog == DialogResult.Yes)
                {
                    string xxx;
                    Entities3 db = new Entities3();
                    var display = db.HeaderTransactions.OrderByDescending(u => u.TransactionID).FirstOrDefault();
                    if (display == null)
                    {
                        xxx = "TR001";
                    }
                    else
                    {
                        int idangka = (Convert.ToInt32(display.TransactionID.Substring(display.TransactionID.Length - 3)) + 1);
                        xxx = "TR" + idangka.ToString().PadLeft(3, '0');
                    }

                    HeaderTransaction top = new HeaderTransaction();
                    DetailTransaction bot = new DetailTransaction();
                    top.UserID = Login.user.UserID;
                    top.TransactionID = xxx;
                    top.TransactionDate = System.DateTime.Today;
                    bot.ProductID = BuyInstrument.ProductID1;
                    bot.Quantity = Convert.ToInt32(label5.Text);
                    bot.TransactionID = xxx;
                    var prodmodel = db.MsProducts.Where(x => x.ProductID == BuyInstrument.ProductID1).FirstOrDefault();
                    prodmodel.ProductStock = BuyInstrument.Stock - Convert.ToInt32(label5.Text);
                    db.Entry(prodmodel).State = System.Data.Entity.EntityState.Modified;
                    db.HeaderTransactions.Add(top);
                    db.DetailTransactions.Add(bot);
                    db.SaveChanges();
                    string change = "Change = " + Convert.ToString(Convert.ToInt32(textBox1.Text) - Convert.ToInt32(label2.Text));
                    MessageBox.Show(change);
                    MessageBox.Show("Thankyou for Purchasing!");
                    this.Hide();
                }

            }
        }
    }

    //private void button2_Click(object sender, EventArgs e)
    //    {
           

    //    }
}

