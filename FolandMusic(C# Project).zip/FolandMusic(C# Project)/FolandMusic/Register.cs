﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FolandMusic
{
    public partial class Register : Form
    {
        MsUser user = new MsUser();
        string gender;
        public Register()
        {
            InitializeComponent();
        }

        private void registerbtn_Click(object sender, EventArgs e)
        {


            if (name.Text == "")
            {
                MessageBox.Show("Name Can't Be Empty!");
            }
            else if (name.Text.Length < 3 || name.Text.Length > 15)
            {
                MessageBox.Show("Name Must Be Between 3 And 15 Characters!");
            }
            else if (!male.Checked && !female.Checked)
            {
                MessageBox.Show("Gender Must Be Selected!");
            }
            else if (dob.Value.Year > 2009)
            {
                MessageBox.Show("You Must Be At Least 10 Years Old To Register!");
            }
            else if (email.Text == "")
            {
                MessageBox.Show("Email Can't Be Empty");
            }
            else if (phone.Text.Length < 9)
            {
                MessageBox.Show("Phone Number Must Be More Then 9 Characters!");
            }
            else if (phone.Text == "")
            {
                MessageBox.Show("Phone Number Can't Be Empty!");
            }
            else if (address.Text == "")
            {
                MessageBox.Show("Address Can't Be Empty!");
            }
            else if (!(address.Text.Substring(address.Text.Length - 6) == "street"))
            {
                MessageBox.Show("Address Must Ends With ‘Street’!");
            }
            else
            {
                using (Entities3 db = new Entities3())
                {
                    string yey;
                    var display = db.MsUsers.OrderByDescending(u => u.UserID).FirstOrDefault();
                    if (display == null)
                    {
                        yey = "US001";
                    }
                    else
                    {
                        int idangka = (Convert.ToInt32(display.UserID.Substring(display.UserID.Length - 3)) + 1);
                        yey = "US" + idangka.ToString().PadLeft(3, '0');
                    }
                    user.UserName = name.Text;
                    user.UserGender = gender;
                    user.UserDOB = dob.Value;
                    user.UserPhone = phone.Text;
                    user.UserEmail = email.Text;
                    user.UserPassword = password.Text;
                    user.UserID = yey;
                    user.UserRole = "Member";
                    user.UserAddress = address.Text;
                    db.MsUsers.Add(user);
                    db.SaveChanges();
                    MessageBox.Show("Success!");
                    this.Hide();
                }

            }
        }

        private void female_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Female";
        }

        private void male_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Male";
        }

        private void Register_Load(object sender, EventArgs e)
        {

        }
    }

       // private void phone_KeyPress(object sender, KeyPressEventArgs e)
       // {
        //    if (char.IsNumber(e.KeyChar))
         //   {
//
        //    }
        //    else
        //    {
        //        e.Handled = e.KeyChar != (char)Keys.Back;
        //        MessageBox.Show("Phone Number Must Be Numeric");
        //    }
        //}
    }

