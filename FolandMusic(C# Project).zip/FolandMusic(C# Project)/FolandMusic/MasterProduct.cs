﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FolandMusic
{
    public partial class MasterProduct : Form
    {
        public static MsProduct Product = new MsProduct();
        public MasterProduct()
        {
            InitializeComponent();
        }

        private void MasterProduct_Load(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            comboBox1.Enabled = false;
            numericUpDown1.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            Entities3 db = new Entities3();

            var query = from u in db.MsProducts//table product ke typ belom nyambung
                        join t in db.MsTypes on u.TypeId equals t.TypeID
                        select new
                        {
                            ProductID = u.ProductID,
                            TypeName = t.TypeName,
                            ProductName = u.ProductName,
                            ProductPrice = u.ProductPrice,
                            ProductStock = u.ProductStock,

                        };
            var queryy = (from x in db.MsTypes select x.TypeName);

            dataGridView1.DataSource = query.ToList();
            comboBox1.DataSource = queryy.ToList();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentRow.Index != -1)
            {
                var produkid = Convert.ToString(dataGridView1.CurrentRow.Cells["ProductID"].Value);
                using (Entities3 db = new Entities3())
                {
                    var display = db.MsProducts.Where(x => x.ProductID == produkid).FirstOrDefault();
                    textBox3.Text = display.ProductID;
                    comboBox1.Text = dataGridView1.CurrentRow.Cells["TypeName"].Value.ToString();
                    textBox1.Text = display.ProductName;
                    textBox2.Text = Convert.ToString(display.ProductPrice);
                    numericUpDown1.Value = display.ProductStock;
                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = false;
            comboBox1.Enabled = true;
            numericUpDown1.Enabled = true;
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = true;
            button5.Enabled = true;
            string idx;
            Entities3 db = new Entities3();
            var display = db.MsProducts.OrderByDescending(u => u.ProductID).FirstOrDefault();
            if (display == null)
            {
                idx = "PR001";
            }
            else
            {
                int idangka = (Convert.ToInt32(display.ProductID.Substring(display.ProductID.Length - 3)) + 1);
                idx = "PR" + idangka.ToString().PadLeft(3, '0');
            }
            textBox3.Text = idx;


        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = false;
            comboBox1.Enabled = true;
            numericUpDown1.Enabled = true;
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = true;
            button5.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Entities3 db = new Entities3();
            string idx = textBox3.Text;
            Product = db.MsProducts.Where(y => y.ProductID == idx).FirstOrDefault();
            if (Product == null)
            {
                MessageBox.Show("Please select a product!");
            }
            else
            {
                DialogResult dialog = MessageBox.Show("Are you sure?", "Are you sure?", MessageBoxButtons.YesNo);
                if (dialog == DialogResult.Yes)
                {
                    db.MsProducts.Remove(Product);
                    db.SaveChanges();
                    this.Hide();
                    MasterProduct Productx = new MasterProduct();
                    Productx.Show();
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Entities3 db = new Entities3();
            var display = db.MsProducts.Where(
                   x => x.ProductID == textBox3.Text).FirstOrDefault();
            if (textBox1.Text == "")
            {
                MessageBox.Show("Product name can’t be empty!");
            }
            else if (textBox1.Text.Length < 5 && textBox1.Text.Length > 20)
            {
                MessageBox.Show("Product name must be between 5 and 20 characters!");
            }
            else if (textBox2.Text == "")
            {
                MessageBox.Show("Product price can’t be empty!");
            }
            else if (Convert.ToInt32(textBox2.Text) <= 0)
            {
                MessageBox.Show("Product price must be more than 0!");
            }
            else if (!textBox2.Text.All(char.IsDigit))
            {
                MessageBox.Show("Product price must be numeric!");
            }
            else if (numericUpDown1.Value <= 0)
            {
                MessageBox.Show("Stock must be more than 0!");
            }
            else if (comboBox1.Text == "" && comboBox1.Text == "--Select Type--")
            {
                MessageBox.Show("Product Type must be selected!");
            }
            else if (display == null)
            {
                var display1 = db.MsTypes.Where(x => x.TypeName == comboBox1.Text).FirstOrDefault();
                Product.ProductID = textBox3.Text;
                Product.ProductName = textBox3.Text;
                Product.ProductPrice = Convert.ToInt32(textBox2.Text);
                Product.ProductStock = Convert.ToInt32(numericUpDown1.Value);
                Product.TypeId = display1.TypeID;

                db.MsProducts.Add(Product);
                db.SaveChanges();

                this.Hide();
                MasterProduct maspro = new MasterProduct();
                maspro.Show();
            }
            else
            {
                var Product = db.MsProducts.Where(xx => xx.ProductID == textBox3.Text).FirstOrDefault();
                var display2 = db.MsTypes.Where(xx => xx.TypeName == comboBox1.Text).FirstOrDefault();
                Product.ProductName = textBox1.Text;
                Product.ProductPrice = Convert.ToInt32(textBox2.Text);
                Product.ProductStock = Convert.ToInt32(numericUpDown1.Value);
                Product.TypeId = display2.TypeID;

                db.Entry(Product).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();

                this.Hide();
                MasterProduct Product1 = new MasterProduct();
                Product1.Show();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            MasterProduct Productxx = new MasterProduct();
            Productxx.Show();
        }
    }
}

    //private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
    //{

    //}

    //private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
    //{

    //}

    //private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
    //    {
            
    //    }



